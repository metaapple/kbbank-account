import { useState } from "react";
import { useNavigate } from "react-router";
import { Plus, Wallet, LogOut, TrendingUp, TrendingDown, BarChart3 } from "lucide-react";
import { TransactionModal, Transaction } from "./TransactionModal";
import { TransactionList } from "./TransactionList";
import { FinancialCharts } from "./FinancialCharts";

export function Dashboard() {
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"income" | "expense">("expense");
  const [editingTransaction, setEditingTransaction] = useState<Transaction | undefined>();
  const [activeTab, setActiveTab] = useState<"transactions" | "charts">("transactions");

  const handleLogout = () => {
    navigate("/login");
  };

  const handleAddTransaction = (type: "income" | "expense") => {
    setModalType(type);
    setEditingTransaction(undefined);
    setIsModalOpen(true);
  };

  const handleEditTransaction = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setIsModalOpen(true);
  };

  const handleSubmitTransaction = (transactionData: Omit<Transaction, "id">) => {
    if (editingTransaction) {
      // 수정
      setTransactions(
        transactions.map((t) =>
          t.id === editingTransaction.id
            ? { ...transactionData, id: editingTransaction.id }
            : t
        )
      );
    } else {
      // 새로 추가
      const newTransaction: Transaction = {
        ...transactionData,
        id: Date.now().toString(),
      };
      setTransactions([...transactions, newTransaction]);
    }
    setIsModalOpen(false);
    setEditingTransaction(undefined);
  };

  const handleDeleteTransaction = (id: string) => {
    if (confirm("정말 삭제하시겠습니까?")) {
      setTransactions(transactions.filter((t) => t.id !== id));
    }
  };

  // 통계 계산
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const thisMonthTransactions = transactions.filter((t) => {
    const date = new Date(t.date);
    return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
  });

  const totalIncome = thisMonthTransactions
    .filter((t) => t.type === "income")
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = thisMonthTransactions
    .filter((t) => t.type === "expense")
    .reduce((sum, t) => sum + t.amount, 0);

  const balance = totalIncome - totalExpense;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("ko-KR").format(amount) + "원";
  };

  return (
    <>
      <div className="w-full max-w-7xl px-4">
        {/* 헤더 */}
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-2">대시보드</h2>
            <p className="text-gray-600">KB 가계부에 오신 것을 환영합니다</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-6 py-3 bg-white border border-gray-200 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors shadow-sm"
          >
            <LogOut className="w-5 h-5" />
            로그아웃
          </button>
        </div>

        {/* 통계 카드 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-md">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-green-500 rounded-lg">
                <Wallet className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-800">이번 달 잔액</h3>
            </div>
            <p className={`text-2xl font-bold ${balance >= 0 ? "text-green-600" : "text-red-600"}`}>
              {formatCurrency(balance)}
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-md">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-blue-500 rounded-lg">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-800">이번 달 수입</h3>
            </div>
            <p className="text-2xl font-bold text-blue-600">{formatCurrency(totalIncome)}</p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-md">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-orange-500 rounded-lg">
                <TrendingDown className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-800">이번 달 지출</h3>
            </div>
            <p className="text-2xl font-bold text-orange-600">{formatCurrency(totalExpense)}</p>
          </div>
        </div>

        {/* 빠른 액션 버튼 */}
        <div className="bg-gradient-to-r from-orange-50 to-amber-50 p-6 rounded-xl border border-orange-200 mb-6 shadow-md">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-gray-800 mb-1">빠른 추가</h3>
              <p className="text-sm text-gray-600">수입과 지출을 기록하세요</p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => handleAddTransaction("income")}
                className="flex items-center gap-2 px-5 py-3 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors shadow-md hover:shadow-lg"
              >
                <Plus className="w-5 h-5" />
                수입 추가
              </button>
              <button
                onClick={() => handleAddTransaction("expense")}
                className="flex items-center gap-2 px-5 py-3 bg-orange-500 text-white rounded-lg font-medium hover:bg-orange-600 transition-colors shadow-md hover:shadow-lg"
              >
                <Plus className="w-5 h-5" />
                지출 추가
              </button>
            </div>
          </div>
        </div>

        {/* 탭 네비게이션 */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab("transactions")}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
              activeTab === "transactions"
                ? "bg-orange-500 text-white shadow-md"
                : "bg-white text-gray-600 hover:bg-gray-50 border border-gray-200"
            }`}
          >
            <TrendingUp className="w-5 h-5" />
            거래 내역
          </button>
          <button
            onClick={() => setActiveTab("charts")}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
              activeTab === "charts"
                ? "bg-orange-500 text-white shadow-md"
                : "bg-white text-gray-600 hover:bg-gray-50 border border-gray-200"
            }`}
          >
            <BarChart3 className="w-5 h-5" />
            통계 분석
          </button>
        </div>

        {/* 컨텐츠 영역 */}
        <div className="mb-8">
          {activeTab === "transactions" ? (
            <TransactionList
              transactions={transactions}
              onEdit={handleEditTransaction}
              onDelete={handleDeleteTransaction}
            />
          ) : (
            <FinancialCharts transactions={transactions} />
          )}
        </div>
      </div>

      {/* 거래 추가/수정 모달 */}
      <TransactionModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingTransaction(undefined);
        }}
        onSubmit={handleSubmitTransaction}
        transaction={editingTransaction}
        type={modalType}
      />
    </>
  );
}
