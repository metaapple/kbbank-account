import { Edit2, Trash2, TrendingUp, TrendingDown } from "lucide-react";
import { Transaction } from "./TransactionModal";

interface TransactionListProps {
  transactions: Transaction[];
  onEdit: (transaction: Transaction) => void;
  onDelete: (id: string) => void;
}

export function TransactionList({
  transactions,
  onEdit,
  onDelete,
}: TransactionListProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("ko-KR").format(amount) + "원";
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("ko-KR", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const sortedTransactions = [...transactions].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  if (transactions.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-md p-12 text-center border border-gray-100">
        <div className="text-gray-400 mb-2">
          <TrendingUp className="w-12 h-12 mx-auto mb-3" />
        </div>
        <p className="text-gray-600">아직 거래 내역이 없습니다</p>
        <p className="text-sm text-gray-500 mt-1">수입 또는 지출을 추가해보세요</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
      <div className="px-6 py-4 bg-gradient-to-r from-orange-50 to-amber-50 border-b border-orange-200">
        <h3 className="font-bold text-gray-800">거래 내역</h3>
        <p className="text-sm text-gray-600 mt-1">
          총 {transactions.length}개의 거래
        </p>
      </div>
      <div className="divide-y divide-gray-100 max-h-[500px] overflow-y-auto">
        {sortedTransactions.map((transaction) => (
          <div
            key={transaction.id}
            className="px-6 py-4 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3 flex-1">
                <div
                  className={`p-2 rounded-lg ${
                    transaction.type === "income"
                      ? "bg-blue-100"
                      : "bg-orange-100"
                  }`}
                >
                  {transaction.type === "income" ? (
                    <TrendingUp className="w-5 h-5 text-blue-600" />
                  ) : (
                    <TrendingDown className="w-5 h-5 text-orange-600" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-semibold text-gray-800">
                      {transaction.category}
                    </span>
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full ${
                        transaction.type === "income"
                          ? "bg-blue-100 text-blue-700"
                          : "bg-orange-100 text-orange-700"
                      }`}
                    >
                      {transaction.type === "income" ? "수입" : "지출"}
                    </span>
                  </div>
                  {transaction.description && (
                    <p className="text-sm text-gray-600 mb-1 truncate">
                      {transaction.description}
                    </p>
                  )}
                  <p className="text-xs text-gray-500">
                    {formatDate(transaction.date)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p
                    className={`font-bold text-lg ${
                      transaction.type === "income"
                        ? "text-blue-600"
                        : "text-orange-600"
                    }`}
                  >
                    {transaction.type === "income" ? "+" : "-"}
                    {formatCurrency(transaction.amount)}
                  </p>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => onEdit(transaction)}
                    className="p-2 hover:bg-blue-50 rounded-lg transition-colors group"
                  >
                    <Edit2 className="w-4 h-4 text-gray-400 group-hover:text-blue-600" />
                  </button>
                  <button
                    onClick={() => onDelete(transaction.id)}
                    className="p-2 hover:bg-red-50 rounded-lg transition-colors group"
                  >
                    <Trash2 className="w-4 h-4 text-gray-400 group-hover:text-red-600" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
