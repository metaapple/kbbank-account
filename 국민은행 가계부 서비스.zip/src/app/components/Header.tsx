import { useNavigate, useLocation } from "react-router";
import { Wallet } from "lucide-react";

export function Header() {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogoClick = () => {
    // 현재 경로에 따라 로그인 또는 회원가입으로 이동
    if (location.pathname === "/signup") {
      navigate("/login");
    } else {
      navigate("/");
    }
  };

  return (
    <header className="bg-white shadow-md border-b-4 border-orange-500">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <button
            onClick={handleLogoClick}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg">
              <Wallet className="w-7 h-7 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-2xl font-bold text-gray-800">KB 가계부</h1>
              <p className="text-sm text-orange-600">국민은행 스마트 가계부</p>
            </div>
          </button>
          <div className="flex gap-3">
            <button
              onClick={() => navigate("/login")}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                location.pathname === "/login" || location.pathname === "/"
                  ? "bg-orange-500 text-white shadow-md"
                  : "text-gray-600 hover:bg-orange-50"
              }`}
            >
              로그인
            </button>
            <button
              onClick={() => navigate("/signup")}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                location.pathname === "/signup"
                  ? "bg-orange-500 text-white shadow-md"
                  : "text-gray-600 hover:bg-orange-50"
              }`}
            >
              회원가입
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
