import { Outlet } from "react-router";
import { Header } from "./Header";
import { Footer } from "./Footer";

export function Root() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
      <Header />
      <main className="flex-1 flex items-center justify-center p-4">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
