import {
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { Transaction } from "./TransactionModal";

interface FinancialChartsProps {
  transactions: Transaction[];
}

const COLORS = [
  "#f97316", // orange-500
  "#fb923c", // orange-400
  "#fdba74", // orange-300
  "#fed7aa", // orange-200
  "#3b82f6", // blue-500
  "#60a5fa", // blue-400
  "#93c5fd", // blue-300
  "#bfdbfe", // blue-200
  "#8b5cf6", // violet-500
];

export function FinancialCharts({ transactions }: FinancialChartsProps) {
  // 카테고리별 지출 데이터
  const expenseByCategory = transactions
    .filter((t) => t.type === "expense")
    .reduce((acc, transaction) => {
      const existing = acc.find((item) => item.name === transaction.category);
      if (existing) {
        existing.value += transaction.amount;
      } else {
        acc.push({ name: transaction.category, value: transaction.amount });
      }
      return acc;
    }, [] as { name: string; value: number }[])
    .sort((a, b) => b.value - a.value);

  // 월별 수입/지출 트렌드
  const monthlyData = transactions.reduce((acc, transaction) => {
    const month = new Date(transaction.date).toLocaleDateString("ko-KR", {
      year: "numeric",
      month: "short",
    });
    const existing = acc.find((item) => item.month === month);
    if (existing) {
      if (transaction.type === "income") {
        existing.income += transaction.amount;
      } else {
        existing.expense += transaction.amount;
      }
    } else {
      acc.push({
        month,
        income: transaction.type === "income" ? transaction.amount : 0,
        expense: transaction.type === "expense" ? transaction.amount : 0,
      });
    }
    return acc;
  }, [] as { month: string; income: number; expense: number }[]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("ko-KR", {
      notation: "compact",
      compactDisplay: "short",
    }).format(value);
  };

  if (transactions.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-md p-12 text-center border border-gray-100">
        <p className="text-gray-600">차트를 표시할 데이터가 없습니다</p>
        <p className="text-sm text-gray-500 mt-1">
          거래 내역을 추가하면 통계가 표시됩니다
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 카테고리별 지출 분석 */}
      {expenseByCategory.length > 0 && (
        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <h3 className="font-bold text-gray-800 mb-6">카테고리별 지출 분석</h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={expenseByCategory}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) =>
                      `${name} (${(percent * 100).toFixed(0)}%)`
                    }
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {expenseByCategory.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) =>
                      new Intl.NumberFormat("ko-KR").format(value) + "원"
                    }
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-col justify-center">
              <div className="space-y-3">
                {expenseByCategory.slice(0, 5).map((item, index) => (
                  <div key={item.name} className="flex items-center gap-3">
                    <div
                      className="w-4 h-4 rounded"
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    />
                    <div className="flex-1">
                      <p className="font-medium text-gray-800">{item.name}</p>
                    </div>
                    <p className="font-semibold text-gray-700">
                      {new Intl.NumberFormat("ko-KR").format(item.value)}원
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 월별 수입/지출 트렌드 */}
      {monthlyData.length > 0 && (
        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <h3 className="font-bold text-gray-800 mb-6">월별 수입/지출 트렌드</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" stroke="#6b7280" />
              <YAxis stroke="#6b7280" tickFormatter={formatCurrency} />
              <Tooltip
                formatter={(value: number) =>
                  new Intl.NumberFormat("ko-KR").format(value) + "원"
                }
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                }}
              />
              <Legend />
              <Bar dataKey="income" fill="#3b82f6" name="수입" radius={[8, 8, 0, 0]} />
              <Bar dataKey="expense" fill="#f97316" name="지출" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* 월별 잔액 추이 */}
      {monthlyData.length > 0 && (
        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <h3 className="font-bold text-gray-800 mb-6">월별 잔액 추이</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart
              data={monthlyData.map((item) => ({
                ...item,
                balance: item.income - item.expense,
              }))}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" stroke="#6b7280" />
              <YAxis stroke="#6b7280" tickFormatter={formatCurrency} />
              <Tooltip
                formatter={(value: number) =>
                  new Intl.NumberFormat("ko-KR").format(value) + "원"
                }
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="balance"
                stroke="#10b981"
                strokeWidth={3}
                name="잔액"
                dot={{ fill: "#10b981", r: 5 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
