export function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200 mt-auto">
      <div className="container mx-auto px-4 py-6">
        <div className="text-center text-sm text-gray-600">
          <p className="mb-2">© 2026 KB 국민은행 가계부 서비스</p>
          <p className="text-xs text-gray-500">
            안전하고 편리한 가계부 관리 서비스
          </p>
        </div>
      </div>
    </footer>
  );
}
